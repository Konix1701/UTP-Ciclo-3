package controller;

public interface IPlanController {
    
    public String listarPlanes(String username);
    
}
